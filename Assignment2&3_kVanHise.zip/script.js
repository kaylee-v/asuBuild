/**
 * @author Kaylee
 */
"use strict";

$(document).ready(function() {
    //hide content of table cell if length over 50
    $('td').each(function() {
        if ($(this).text().length > 50) {
            $(this).addClass('overflow');
            }
    });
    //reveal table cell content on click
    $('td').click(function() { 
        $(this).toggleClass('reveal');
    });
    
    //ran into problems when selecting one focus after another with course 334
    //which is included in 3 diffferent focus areas
    //so instead of toggleClass, I used an if else statement to check
    //if the class exists and toggle manually
    $('#print_button').click(function() {
        $('.web, .photo, .animation').removeClass('highlight');
        if ($('.print').hasClass('highlight')) {
            $('.print').removeClass('highlight');
        } else {
            $('.print').addClass('highlight');
        }
    });
    
    $('#web_button').click(function() {
        $('.print, .photo, .animation').removeClass('highlight');
        if ($('.web').hasClass('highlight')) {
            $('.web').removeClass('highlight');
        } else {
            $('.web').addClass('highlight');
        }
    });
    $('#photo_button').click(function() {
        $('.print, .web, .animation').removeClass('highlight');
        if ($('.photo').hasClass('highlight')) {
            $('.photo').removeClass('highlight');
        } else {
            $('.photo').addClass('highlight');
        }
    });
    $('#animation_button').click(function() {
        $('.print, .web, .photo').removeClass('highlight');
        if ($('.animation').hasClass('highlight')) {
            $('.animation').removeClass('highlight');
        } else {
            $('.animation').addClass('highlight');
        }
    });
    
    //toggle upper and lower division highlight
    $('#lower_button').click(function() {
        $('.upper').removeClass('class_highlight');
        $('.lower').toggleClass('class_highlight');
    });
    $('#upper_button').click(function() {
        $('.lower').removeClass('class_highlight');
        $('.upper').toggleClass('class_highlight');
    });
    
    //clear search
    $('#clear_button').click(function() {
       $('.print, .web, .photo, .animation').removeClass('highlight');
       $('.lower, .upper').removeClass('class_highlight'); 
    });
    
    $('tr:odd').addClass('alt');
});
